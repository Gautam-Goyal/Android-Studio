package com.example.learnlanguage;

import android.content.Context;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class WordAdapter extends ArrayAdapter<Word> {

    /** Resource ID for the background color for this list of words */
    private int mColorResourceId;


    /**
     * This is our own custom constructor (it doesn't mirror a superclass constructor).
     * The context is used to inflate the layout file, and the list is the data we want
     * to populate into the lists.
     *
     * @param context        The current context(recieved when WordAdapter constructor is called. Used to inflate the layout file.
     * @param NumberList      A List of Word objects to display in a list
     * @param colorResourceId is the resource ID for the background color for this list of words
     */
    public WordAdapter(Context context,ArrayList<Word> NumberList,int colorResourceId)
    {
        // Here, we initialize the ArrayAdapter's internal storage for the context and the list.
        // the second argument is used when the ArrayAdapter is populating a single TextView.
        // Because this is a custom adapter for two TextViews and an ImageView, the adapter is not
        // going to use this second argument, so it can be any value. Here, we used 0.
        super(context,0,NumberList);
        mColorResourceId = colorResourceId;
    }

    /**
     * Provides a view for an AdapterView (ListView, GridView, etc.)
     *
     * @param position The position in the list of data that should be displayed in the
     *                 list item view.
     * @param convertView The recycled view to populate.
     * @param parent The parent ViewGroup that is used for inflation.
     * @return The View for the position in the AdapterView.
     */

    @Override
    public View getView(int position,View convertView,ViewGroup parent) {
        // Get the {@link Word} object located at this position in the list
        Word currentWordObject =getItem(position);

        // Check if the existing view is being reused, otherwise inflate the view
        //We do the following step generally when we start an app and initially there is no view in recycle phase.
        View listItemView=convertView;
        if (listItemView == null)
        {
            listItemView= LayoutInflater.from(getContext()).inflate(R.layout.list_item,parent,false);
        }

        // Set the theme color for the list item
        View textContainer = listItemView.findViewById(R.id.text_container);
        // Find the color that the resource ID maps to
        int color = ContextCompat.getColor(getContext(), mColorResourceId);
        textContainer.setBackgroundColor(color);

        // Find the TextView in the list_item.xml layout with the ID miwok_translation
        TextView miwokText =(TextView) listItemView.findViewById(R.id.miwok_translation);
        // Get the miwok_translation from the current Word object and
        // set this text on the miwokText TextView
        miwokText.setText(currentWordObject.getMiwokTranslation());

        TextView defaultText =(TextView) listItemView.findViewById(R.id.default_translation);
        defaultText.setText(currentWordObject.getDefaultTranslation());

        ImageView imagesOfList =(ImageView) listItemView.findViewById(R.id.imagesInList);

        //checks if at that position image is there or not.If yes then if block works otherwise else block works.
        if(currentWordObject.hasImage()) {
            imagesOfList.setImageResource(currentWordObject.getImageResourceid());
            //we have set the visibility again because if the user first go to phrases then visibility will be gone and we will not see images in other activities too.
            imagesOfList.setVisibility(View.VISIBLE);
        }
        else
            imagesOfList.setVisibility(View.GONE);

        return listItemView;
    }
}
