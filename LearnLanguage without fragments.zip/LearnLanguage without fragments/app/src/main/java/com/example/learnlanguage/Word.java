package com.example.learnlanguage;

public class Word {
    /** Default translation for the word */
    private String mDefaultTranslation;

    /** Miwok translation for the word */
    private String mMiwokTranslation;

    private int mImageResourceid=No_Image_Used;
    private static final int No_Image_Used=-1;

    private int mMediaResourceId;

    /**
     * Create a new Word object.
     *
     * @param defaultTranslation is the word in a language that the user is already familiar with
     *                           (such as English)
     * @param miwokTranslation is the word in the Miwok language
     * @param mediaResourceId is the integer which stores id for each song
     */
    public Word(String defaultTranslation, String miwokTranslation ,int mediaResourceId) {
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mMediaResourceId=mediaResourceId;
    }

    //Second constructor for those activities who have image with them
    public Word(String defaultTranslation, String miwokTranslation, int imageResourceid ,int mediaResouceId) {
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mImageResourceid=imageResourceid;
        mMediaResourceId=mediaResouceId;
    }

    /**
     * Get the default translation of the word.
     */
    public String getDefaultTranslation() {
        return mDefaultTranslation;
    }

    /**
     * Get the Miwok translation of the word.
     */
    public String getMiwokTranslation() {
        return mMiwokTranslation;
    }

    public int getImageResourceid() {
        return mImageResourceid;
    }

    public int getMediaResourceId()
    {return mMediaResourceId;}

    public boolean hasImage(){
        return mImageResourceid!=No_Image_Used;
    }
}
